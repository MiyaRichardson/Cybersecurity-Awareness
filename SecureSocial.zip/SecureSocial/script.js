
function getVal(q) {
  const el = document.querySelector(`input[name="${q}"]:checked`);
  return el ? el.value : "";
}

document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("assessmentForm");

  if (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();

      let score = 0;
      const age = document.querySelector('input[name="ageGroup"]:checked');

      if (!age) {
        alert("Please select your age group.");
        return;
      }
      localStorage.setItem("userAgeGroup", age.value);

      const answers = { ageGroup: age.value };

      // Get answers and calculate score
      for (let i = 1; i <= 12; i++) {
        const val = getVal(`q${i}`);
        if (val === "") {
          alert("Please answer all questions.");
          return;
        }
        score += parseInt(val, 10);
        answers[`q${i}`] = val;
      }

      answers.totalScore = score;
      localStorage.setItem("cyberScore", score);

      
      window.location.href = "results.html";
    });
  }

  // Mobile menu toggle
  const toggle = document.querySelector(".menu-toggle");
  const menu = document.querySelector(".nav-menu");

  if (toggle && menu) {
    toggle.addEventListener("click", () => {
      menu.classList.toggle("open");
    });
  }

  // Results page logic
  if (window.location.pathname.includes("results.html")) {
    const score = localStorage.getItem("cyberScore");
    const userAge = localStorage.getItem("userAgeGroup");

    if (!score) {
      window.location.href = "assessment.html";
      return;
    }

    const numericScore = parseInt(score, 10);
    let rating = "";
    let advice = [];

    if (numericScore >= 18) {
      rating = `Score: ${score} - ✅ Low Risk`;
      advice = [
        "Excellent work! You're following strong cyber hygiene practices.",
        "Keep using unique, strong passwords and stay alert to threats.",
        "Consider mentoring others or staying updated via security blogs.",
      ];
    } else if (numericScore >= 9) {
      rating = `Score: ${score} - ⚠️ Moderate Risk`;
      advice = [
        "You’re doing some things right — great start!",
        "Improve your password habits and enable MFA on more accounts.",
        "Watch for phishing and use a password manager if you don’t already.",
      ];
    } else {
      rating = `Score: ${score} - 🔥 High Risk`;
      advice = [
        "You are at significant risk — act now to improve your digital safety.",
        "Avoid public Wi-Fi for sensitive actions, and enable two-factor authentication.",
        "Use strong passwords and a password manager, and update your software regularly.",
      ];
    }

    const resultBox = document.getElementById("scoreResult");
    const adviceList = document.getElementById("adviceList");
    const ageDisplay = document.getElementById("userAgeGroup");

    if (ageDisplay && userAge) {
      ageDisplay.innerHTML = `Age Group: <strong>${userAge}</strong>`;
    }

    if (resultBox) resultBox.textContent = rating;
    if (adviceList) adviceList.innerHTML = advice.map((a) => `<li>${a}</li>`).join("");
  }

  // Simulator Caption Analysis
  const captionForm = document.getElementById("simScenarioForm");

  if (captionForm) {
    captionForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const caption = document.getElementById("captionInput").value.toLowerCase();
      const feedbackDiv = document.getElementById("simFeedback");
      const feedback = [];

      if (caption.includes("rome") || caption.includes("grand roma") || caption.includes("hotel")) {
        feedback.push("🏨 Mentioning your exact location or hotel can make you a target for stalking or theft.");
      }

      if (caption.includes("june 14") || caption.includes("14th june") || caption.match(/\b(june|14)\b/)) {
        feedback.push("📅 Sharing specific dates (like your travel or birthday) can inform attackers when you’re away from home.");
      }

      if (caption.includes("birthday") || caption.includes("turning") || caption.match(/(?:\d{1,2})(st|nd|rd|th)?\s*birthday/)) {
        feedback.push("🎂 Birthday mentions can be used in identity theft and password recovery attacks.");
      }

      if (caption.includes("vacation") || caption.includes("on holiday") || caption.includes("travel")) {
        feedback.push("✈️ Posting while away can signal that your home is unoccupied.");
      }

      if (feedback.length === 0) {
        feedback.push("✅ No immediate threats detected — great job staying private!");
      }

      if (feedbackDiv) {
        feedbackDiv.innerHTML = feedback.map((f) => `<div class="feedback-box">${f}</div>`).join("");
      }
    });
  }

  // Social Media Scam Detector Simulation
  const simContainer = document.querySelector('.container');

  if (simContainer && window.location.pathname.includes("simulator.html")) {
    const scamSimWrapper = document.createElement('section');
    scamSimWrapper.className = 'scam-simulation';

    scamSimWrapper.innerHTML = `
      <h2>Social Media Scam Detector</h2>
      <p>Below are 3 social media messages. Decide if each one is a scam or NOT a scam.</p>
      <form id="scamSimForm">
        <div class="scam-message" data-id="1">
          <p><strong>Message 1:</strong> "Congrats! You've won a free iPhone! Click <a href="#">here</a> to claim now."</p>
          <label><input type="radio" name="msg1" value="scam" required> Scam</label>
          <label><input type="radio" name="msg1" value="not-scam"> Not a Scam</label>
        </div>
        <div class="scam-message" data-id="2">
          <p><strong>Message 2:</strong> "Hey, saw your post about your phone. Check out this new app that helps secure it!"</p>
          <label><input type="radio" name="msg2" value="scam" required> Scam</label>
          <label><input type="radio" name="msg2" value="not-scam"> Not a Scam</label>
        </div>
        <div class="scam-message" data-id="3">
          <p><strong>Message 3:</strong> "Urgent! Your bank account will be locked unless you verify your info <a href='#'>here</a>."</p>
          <label><input type="radio" name="msg3" value="scam" required> Scam</label>
          <label><input type="radio" name="msg3" value="not-scam"> Not a Scam</label>
        </div>
        <button type="submit" class="btn">Submit Answers</button>
      </form>
      <div id="scamResult" class="result-box" style="display:none;"></div>
    `;

    simContainer.appendChild(scamSimWrapper);

    const scamSimForm = document.getElementById('scamSimForm');
    const scamResult = document.getElementById('scamResult');

    scamSimForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const correctAnswers = {
        msg1: 'scam',
        msg2: 'not-scam',
        msg3: 'scam',
      };

      const formData = new FormData(scamSimForm);
      let score = 0;
      const total = Object.keys(correctAnswers).length;

      for (const [key, value] of formData.entries()) {
        if (correctAnswers[key] === value) score++;
      }

      scamResult.style.display = 'block';
      scamResult.innerHTML = `You identified ${score} out of ${total} correctly.<ul>`;

      if (score === total) {
        scamResult.innerHTML += `<li>Excellent! You can spot scams well.</li>`;
      } else {
        scamResult.innerHTML += `<li>Review the following:</li>`;
        if (formData.get('msg1') !== correctAnswers.msg1) {
          scamResult.innerHTML += `<li>Message 1 is a scam — beware of prize scams and suspicious links.</li>`;
        }
        if (formData.get('msg2') !== correctAnswers.msg2) {
          scamResult.innerHTML += `<li>Message 2 is NOT a scam — it’s a genuine friendly message.</li>`;
        }
        if (formData.get('msg3') !== correctAnswers.msg3) {
          scamResult.innerHTML += `<li>Message 3 is a scam — it pressures you to give sensitive info.</li>`;
        }
      }
      scamResult.innerHTML += `</ul>`;

      scamResult.scrollIntoView({ behavior: 'smooth' });
    });
  }
});

